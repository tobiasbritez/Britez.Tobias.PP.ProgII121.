package com.mycompany.acuario.parcial;

public class Pez extends Especie implements Alimenta {
    private double longitudMaxima;

    public Pez(String nombre, String tanque, TipoAgua tipoAgua, double longitudMaxima) {
        super(nombre, tanque, tipoAgua);
        this.longitudMaxima = longitudMaxima;
    }

    @Override
    public void alimentar() {
        System.out.println(nombreComun + " ha sido alimentado.");
    }

    @Override
    public String getDescripcion() {
        return "Pez - Longitud máxima: " + longitudMaxima + " cm";
    }
}
