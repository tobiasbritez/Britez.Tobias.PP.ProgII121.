package com.mycompany.acuario.parcial;

public class EspecieDuplicadaException extends Exception {
    public EspecieDuplicadaException(String mensaje) {
        super(mensaje);
    }
}