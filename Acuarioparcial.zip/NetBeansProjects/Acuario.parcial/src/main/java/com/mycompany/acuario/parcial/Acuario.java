package com.mycompany.acuario.parcial;

import java.util.*;

public class Acuario {
    private final List<Especie> especies = new ArrayList<>();

    public void agregarEspecie(Especie especie) throws EspecieDuplicadaException {
        for (Especie e : especies) {
            if (e.getNombreComun().equalsIgnoreCase(especie.getNombreComun()) &&
                e.getTanque().equalsIgnoreCase(especie.getTanque())) {
                throw new EspecieDuplicadaException("La especie '" + especie.getNombreComun() +
                    "' ya existe en el tanque '" + especie.getTanque() + "'.");
            }
        }
        especies.add(especie);
    }

    public void mostrarEspecies() {
        for (Especie e : especies) {
            System.out.println(e.getNombreComun() + " | Tanque: " + e.getTanque() + 
                " | Agua: " + e.getTipoAgua() + " | " + e.getDescripcion());
        }
    }

    public void alimentarEspecies() {
        for (Especie e : especies) {
            if (e instanceof Alimenta alimenta) {
                alimenta.alimentar();
            } else {
                System.out.println(e.getNombreComun() + " no necesita ser alimentado.");
            }
        }
    }

    public void filtrarPorTipoAgua(TipoAgua tipo) {
        for (Especie e : especies) {
            if (e.getTipoAgua() == tipo) {
                System.out.println(e.getNombreComun() + " - " + e.getDescripcion());
            }
        }
    }

    static class parcial {

        public parcial() {
        }
    }
}
