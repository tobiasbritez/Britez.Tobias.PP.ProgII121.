package com.mycompany.acuario.parcial;

public interface Alimenta {
    void alimentar();
}
